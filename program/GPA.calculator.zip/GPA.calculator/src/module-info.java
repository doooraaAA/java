/**
 * 
 */
/**
 * @author 31677
 *
 */
module GPA.calculator {
}